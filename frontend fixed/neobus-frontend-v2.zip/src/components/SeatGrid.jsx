export default function SeatGrid({ seats, selected, setSelected, columns=8 }) {
  const toggle = (no, available) => {
    if (!available) return
    if (selected.includes(no)) setSelected(selected.filter(s=>s!==no))
    else setSelected([...selected, no])
  }
  return (
    <div className="grid" style={{gridTemplateColumns:`repeat(${columns},minmax(0,1fr))`}}>
      {(seats||[]).map(({number, available}, idx)=>{
        const isSel = selected.includes(number)
        return (
          <button key={number||idx} onClick={()=>toggle(number, available)}
            className={'m-1 h-10 rounded-lg border text-xs ' + (available ? (isSel?'bg-brand-500/90 border-brand-400':'bg-white/10 border-white/20 hover:bg-white/20') : 'bg-red-500/30 border-red-400/40 cursor-not-allowed')}>
            {number}
          </button>
        )
      })}
    </div>
  )
}
