export default {
  content: ["./index.html","./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: { brand: { 500:"#5366ff", 600:"#3849e6" } },
      boxShadow: { glass: "0 8px 32px 0 rgba(31,38,135,.25)" }
    }
  },
  plugins: []
}
