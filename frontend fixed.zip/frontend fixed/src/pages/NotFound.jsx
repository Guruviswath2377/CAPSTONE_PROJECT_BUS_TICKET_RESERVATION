export default function NotFound()
{ 
    return <main className='px-4 py-20 text-center'>
        <div className='text-2xl font-semibold'>
            Page not found
        </div>
    </main>
}
