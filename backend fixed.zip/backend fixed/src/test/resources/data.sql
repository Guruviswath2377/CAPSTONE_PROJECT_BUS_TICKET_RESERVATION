
INSERT INTO route (id, source, destination) VALUES (1, 'A', 'B');
INSERT INTO bus (id, bus_number, total_seats) VALUES (1, 'KA-01-AB-1234', 40);
