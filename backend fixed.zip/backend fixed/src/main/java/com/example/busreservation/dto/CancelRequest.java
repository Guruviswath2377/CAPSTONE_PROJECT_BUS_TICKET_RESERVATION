package com.example.busreservation.dto;

import lombok.Data;

@Data
public class CancelRequest {
    private String reason;
}
