package com.example.busreservation.model;

public enum Role {
    ADMIN, USER
}
